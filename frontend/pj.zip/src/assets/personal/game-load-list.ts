export const gameloads = [
    {
        id: 1,
        name: '收发室初级',
        finish: '未完成',
    },
    {
        id: 2,
        name: '收发室高级',
        finish: '未完成',
    },
    {
        id: 3,
        name: '十倍放大镜',
        finish: '未完成',
    },
    {
        id: 4,
        name: '光线检测',
        finish: '未完成',
    },
    {
        id: 5,
        name: '绿野仙踪',
        finish: '未完成',
    },
];
