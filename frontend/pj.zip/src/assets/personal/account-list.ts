export const accounts = [
    {
        name: '',
        rgstime: '',
        email: '',
    },

];
