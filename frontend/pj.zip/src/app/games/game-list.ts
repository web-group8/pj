export const games = [
    {
        id: 1,
        name: '关卡1',
        type: '2D',
        difficulty: '简单',
    },
    {
        id: 2,
        name: '关卡2',
        type: '2D',
        difficulty: '简单',
    },
    {
        id: 3,
        name: '关卡3',
        type: '2D',
        difficulty: '中等',
    },
    {
        id: 4,
        name: '关卡4',
        type: '3D',
        difficulty: '困难',
    },
    {
        id: 5,
        name: '关卡5',
        type: '3D',
        difficulty: '困难',
    },
];